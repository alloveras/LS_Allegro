#ifndef __al_included_allegro5_aintern_transform_h
#define __al_included_allegro5_aintern_transform_h


bool _al_transform_is_translation(const ALLEGRO_TRANSFORM* trans,
   float *dx, float *dy);


#endif
